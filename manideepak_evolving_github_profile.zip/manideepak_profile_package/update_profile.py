#!/usr/bin/env python3
"""Refresh the profile README from the account's real public repository data."""

from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

USERNAME = os.environ.get("PROFILE_USERNAME", "manideepakpaladugu-sketch")
README_PATH = "README.md"
START_MARKER = "<!-- PROFILE-AUTO:START -->"
END_MARKER = "<!-- PROFILE-AUTO:END -->"
API_BASE = "https://api.github.com"


def get_json(url: str):
    request = Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "profile-readme-refresh/1.0",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urlopen(request, timeout=25) as response:
            return json.load(response)
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:400]
        raise RuntimeError(f"GitHub API returned HTTP {exc.code}: {detail}") from exc
    except URLError as exc:
        raise RuntimeError(f"Could not reach GitHub API: {exc.reason}") from exc


def safe_text(value: str) -> str:
    """Keep repository descriptions from breaking the generated Markdown list."""
    value = re.sub(r"\s+", " ", (value or "")).strip()
    value = value.replace("|", "\\|").replace("[", "\\[").replace("]", "\\]")
    if len(value) > 150:
        value = value[:147].rstrip() + "..."
    return value


def date_text(value: str | None) -> str:
    if not value:
        return "date unavailable"
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.astimezone(timezone.utc).strftime("%d %b %Y, %H:%M UTC")
    except ValueError:
        return "date unavailable"


def generate_block() -> str:
    encoded_user = quote(USERNAME, safe="")
    repos = get_json(
        f"{API_BASE}/users/{encoded_user}/repos?type=owner&sort=updated&direction=desc&per_page=100"
    )
    if not isinstance(repos, list):
        raise RuntimeError("GitHub API response did not contain a repository list.")

    # Don't count the profile README itself as a project. Forks aren't presented
    # as work created by the learner; archived repositories still remain part of history.
    projects = [
        repo for repo in repos
        if repo.get("name", "").casefold() != USERNAME.casefold()
        and not repo.get("fork", False)
    ]

    total_repos = len(projects)
    total_stars = sum(int(repo.get("stargazers_count") or 0) for repo in projects)
    language_counts: dict[str, int] = {}
    for repo in projects:
        language = repo.get("language")
        if language:
            language_counts[language] = language_counts.get(language, 0) + 1

    language_list = sorted(language_counts, key=lambda name: (-language_counts[name], name.casefold()))
    if language_list:
        shown = language_list[:6]
        language_text = " · ".join(f"`{name}` ({language_counts[name]} repo{'s' if language_counts[name] != 1 else ''})" for name in shown)
        if len(language_list) > len(shown):
            language_text += f" · and {len(language_list) - len(shown)} more"
    else:
        language_text = "Not detected yet. Languages will appear when public repositories contain recognized code."

    lines = [
        "## 📊 My GitHub journey",
        "",
        f"| Public repositories | Stars received | Primary languages detected |",
        "|:--:|:--:|:--|",
        f"| **{total_repos}** | **{total_stars}** | {language_text} |",
        "",
    ]

    recently_pushed = sorted(
        projects,
        key=lambda repo: repo.get("pushed_at") or repo.get("updated_at") or "",
        reverse=True,
    )[:5]

    lines.extend(["### 🪴 Recent public work", ""])
    if not recently_pushed:
        lines.extend([
            "No public practice repositories yet, and that's completely fine.",
            "When I publish my first small experiment, it will appear here automatically.",
        ])
    else:
        for repo in recently_pushed:
            name = safe_text(repo.get("name") or "Untitled repository")
            url = repo.get("html_url") or f"https://github.com/{USERNAME}"
            description = safe_text(repo.get("description") or "A work in progress.")
            language = repo.get("language") or "Language not detected yet"
            pushed = date_text(repo.get("pushed_at") or repo.get("updated_at"))
            stars = int(repo.get("stargazers_count") or 0)
            lines.append(f"- **[{name}]({url})** · {description}")
            lines.append(f"  - `{language}` · last pushed {pushed} · ⭐ {stars}")

    lines.extend([
        "",
        "> This snapshot is generated from public repositories. It updates when GitHub Actions runs and the data changes.",
        "> GitHub's contribution calendar on my profile separately tracks eligible contributions.",
    ])
    return "\n".join(lines)


def main() -> int:
    try:
        with open(README_PATH, "r", encoding="utf-8") as file:
            readme = file.read()
        if START_MARKER not in readme or END_MARKER not in readme:
            raise RuntimeError(
                f"README.md must contain both markers: {START_MARKER} and {END_MARKER}"
            )
        if readme.index(START_MARKER) >= readme.index(END_MARKER):
            raise RuntimeError("The README auto-update markers are in the wrong order.")

        generated = generate_block()
        pattern = re.compile(
            re.escape(START_MARKER) + r".*?" + re.escape(END_MARKER),
            flags=re.DOTALL,
        )
        replacement = f"{START_MARKER}\n{generated}\n{END_MARKER}"
        updated = pattern.sub(lambda _match: replacement, readme, count=1)
        if updated == readme:
            print("Profile snapshot is already current; no changes needed.")
            return 0
        with open(README_PATH, "w", encoding="utf-8", newline="\n") as file:
            file.write(updated)
        print("Updated the profile snapshot from public GitHub repository data.")
        return 0
    except (OSError, RuntimeError, json.JSONDecodeError) as exc:
        print(f"Profile refresh failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
