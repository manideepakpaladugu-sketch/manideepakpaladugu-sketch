<div align="center">
  <img src="./banner.png" alt="Manideepak's developer banner" width="100%" />
  <h1>Hi, I'm Manideepak 👋</h1>
  <h3>First-year B.Tech student · Beginner developer · Learning in public</h3>
  <p>I'm at the beginning of my programming journey. This profile will grow as I practice, experiment, build small things, and learn from mistakes.</p>
  <p>
    <img src="https://img.shields.io/badge/Stage-Just%20getting%20started-16c7d9?style=for-the-badge" alt="Stage: just getting started" />
    <img src="https://img.shields.io/badge/Approach-Learn%20by%20building-7269ef?style=for-the-badge" alt="Approach: learn by building" />
  </p>
</div>

---

## 🌱 A little about my journey

I'm starting from the fundamentals and giving myself room to learn properly. I don't have to know everything today. I'll keep adding real practice, discoveries, and projects as I go.

## 🧭 What this profile tracks

- **Real work:** public repositories I create and update.
- **Progress signals:** repository count, stars, and primary languages detected in those repositories.
- **Recent activity:** the latest public repositories I've pushed code to.
- **Learning notes:** a small optional log of lessons, attempts, and next steps.

The live snapshot below is refreshed automatically by GitHub Actions. It reflects public GitHub work, not offline study time or private repositories.

<!-- PROFILE-AUTO:START -->
## 📊 My GitHub journey

I'm just getting started. My first public practice repository will appear here when I publish it.
<!-- PROFILE-AUTO:END -->

## 📝 Learning notes

I can keep short notes in [`LEARNING_LOG.md`](LEARNING_LOG.md): what I tried, what I learned, and what I want to try next. This part is intentionally personal instead of pretending software can know what I learned.

## 🤝 Say hello

You can follow my journey here on [GitHub](https://github.com/manideepakpaladugu-sketch). More will appear here as I build it, one step at a time. 🌱
