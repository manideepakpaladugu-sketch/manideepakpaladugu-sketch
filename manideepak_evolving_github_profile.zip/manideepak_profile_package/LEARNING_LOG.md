# Learning Log 🌱

A tiny notebook for the parts of learning that GitHub can't detect automatically. Add an entry only when you feel you have something worth remembering. Short notes are enough.

## Entry template

### YYYY-MM-DD · What I tried
- **Tried:**
- **Learned:**
- **Next step:**

---

## My notes

_Add your first note whenever you're ready. No pressure to fill this on a schedule._
